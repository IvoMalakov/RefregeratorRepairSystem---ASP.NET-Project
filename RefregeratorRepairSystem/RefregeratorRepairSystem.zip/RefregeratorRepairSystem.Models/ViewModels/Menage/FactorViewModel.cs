﻿namespace RefregeratorRepairSystem.Models.ViewModels.Menage
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}
